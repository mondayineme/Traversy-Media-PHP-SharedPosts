<?php
  // DB Params
  define("DB_HOST", "localhost");
  define("DB_USER", "_ADD_DB_USER_");
  define("DB_PASS", "_ADD_DB_PASS_");
  define("DB_NAME", "_ADD_DB_NAME_");

  // App Root
  define('APPROOT', dirname(dirname(__FILE__)));
  // URL Root (eg. http://myapp.com or http://localhost/myapp)
  define('URLROOT', 'http://_ADD_ROOT_URL_');
  // Site Name
  define('SITENAME', '_ADD_SITE_NAME_');
  