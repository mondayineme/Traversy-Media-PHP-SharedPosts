<?php require APPROOT . '/views/inc/header.php'; ?>
  <h1>About</h1>
  <p>This is a test about page</p>
  <p>App Version: <?php echo $data['version']; ?></p>
<?php require APPROOT . '/views/inc/footer.php'; ?>